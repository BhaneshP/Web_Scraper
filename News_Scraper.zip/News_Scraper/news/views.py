from django.shortcuts import render
import requests
from bs4 import BeautifulSoup

# GEtting news from Times of India

toi_r = requests.get("https://timesofindia.indiatimes.com/briefs")
toi_soup = BeautifulSoup(toi_r.content, 'html.parser')

toi_headings = toi_soup.find_all('h2')

toi_headings = toi_headings[2:17] # removing footers

toi_news = []

for th in toi_headings:
    toi_news.append(th.text)



#Getting news from Hindustan times

import requests
from bs4 import BeautifulSoup

r = requests.get("https://economictimes.indiatimes.com/markets/brief/52655364.cms")
soup = BeautifulSoup(r.content, 'html.parser')
tet_headings = soup.findAll("h2")
tet_news = []

for tet in tet_headings:
    tet_news.append(tet.text)



def index(req):
    return render(req, 'news/index.html', {'toi_news':toi_news, 'tet_news': tet_news})

